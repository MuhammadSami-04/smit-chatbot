"""Persistent ChromaDB wrapper for the SMIT knowledge base collection."""
from __future__ import annotations

import chromadb

from src.chunker import Chunk
from src.config import CHROMA_PATH, COLLECTION_NAME

_client: chromadb.ClientAPI | None = None


def get_client() -> chromadb.ClientAPI:
    global _client
    if _client is None:
        _client = chromadb.PersistentClient(
            path=str(CHROMA_PATH),
            settings=chromadb.Settings(
                anonymized_telemetry=False,
                allow_reset=True,
            ),
        )
    return _client


def get_collection(client: chromadb.ClientAPI | None = None):
    client = client or get_client()
    return client.get_or_create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"},
    )


def rebuild_collection(client: chromadb.ClientAPI | None = None):
    """Drop and recreate the collection from scratch."""
    client = client or get_client()
    try:
        client.delete_collection(COLLECTION_NAME)
    except Exception:
        pass
    return client.get_or_create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"},
    )


def upsert_chunks(collection, chunks: list[Chunk], embeddings: list[list[float]]) -> None:
    """Insert or update chunks. Deterministic chunk_ids make this idempotent:
    re-running ingestion with unchanged chunks updates the same rows instead
    of duplicating them."""
    if not chunks:
        return
    collection.upsert(
        ids=[c.chunk_id for c in chunks],
        documents=[c.text for c in chunks],
        embeddings=embeddings,
        metadatas=[
            {
                "document": c.document,
                "page_start": c.page_start,
                "page_end": c.page_end,
                "line_start": c.line_start,
                "line_end": c.line_end,
                "section": c.section,
                "source_url": c.source_url,
            }
            for c in chunks
        ],
    )


def prune_stale_ids(collection, current_ids: set[str]) -> int:
    """Remove any stored chunk ids that no longer exist in the current
    chunk set (e.g. the PDF changed and a chunk's boundaries shifted)."""
    existing = collection.get(include=[])["ids"]
    stale = [i for i in existing if i not in current_ids]
    if stale:
        collection.delete(ids=stale)
    return len(stale)
