"""Central configuration loaded from environment variables."""
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

PDF_PATH = Path(os.getenv("PDF_PATH", BASE_DIR / "data" / "SMIT_Master_Knowledge_Base.pdf"))
CHROMA_PATH = Path(os.getenv("CHROMA_PATH", BASE_DIR / "chroma_db"))
COLLECTION_NAME = os.getenv("COLLECTION_NAME", "smit_knowledge_base")

EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")

CHUNK_SIZE_TOKENS = int(os.getenv("CHUNK_SIZE_TOKENS", "700"))
CHUNK_OVERLAP_TOKENS = int(os.getenv("CHUNK_OVERLAP_TOKENS", "100"))

TOP_K = int(os.getenv("TOP_K", "6"))
RETRIEVAL_THRESHOLD = float(os.getenv("RETRIEVAL_THRESHOLD", "0.42"))

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")

COMPLAINTS_DB_PATH = Path(os.getenv("COMPLAINTS_DB_PATH", BASE_DIR / "data" / "complaints.db"))

DOCUMENT_NAME = "SMIT_Master_Knowledge_Base.pdf"
