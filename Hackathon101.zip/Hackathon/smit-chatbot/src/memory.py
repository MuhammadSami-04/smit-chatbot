"""Short-term, in-process conversation memory (per session, not persisted).

Distinguishes conversation memory (things the user said in this session)
from knowledge-base facts (retrieved chunks). Conversation memory is only
used to make follow-up questions searchable; it is never treated as an
authoritative SMIT fact.
"""
from __future__ import annotations

import re
from collections import defaultdict

MAX_TURNS_KEPT = 12
MAX_HISTORY_IN_PROMPT = 4

FOLLOWUP_MARKERS = re.compile(
    r"\b(it|that|this|those|these|they|which one|the first|the second|"
    r"what about|and|also|earlier|previous)\b",
    re.IGNORECASE,
)

_sessions: dict[str, list[tuple[str, str]]] = defaultdict(list)


def add_turn(session_id: str, role: str, content: str) -> None:
    history = _sessions[session_id]
    history.append((role, content))
    if len(history) > MAX_TURNS_KEPT:
        del history[: len(history) - MAX_TURNS_KEPT]


def get_history(session_id: str) -> list[tuple[str, str]]:
    return list(_sessions.get(session_id, []))


def get_history_snippet(session_id: str) -> str:
    history = get_history(session_id)[-MAX_HISTORY_IN_PROMPT:]
    return "\n".join(f"{role}: {content}" for role, content in history)


def clear_session(session_id: str) -> None:
    _sessions.pop(session_id, None)


def _looks_like_followup(question: str) -> bool:
    word_count = len(question.split())
    return word_count <= 6 or bool(FOLLOWUP_MARKERS.search(question))


def build_search_query(session_id: str, question: str) -> str:
    """Expand a likely follow-up question with the last user question's
    topic, without blindly dumping the whole conversation into the search."""
    if not _looks_like_followup(question):
        return question

    history = get_history(session_id)
    # exclude the current question itself, which may already be the most
    # recent "user" turn if this is called after add_turn() logged it.
    last_user_questions = [c for r, c in reversed(history) if r == "user" and c != question]
    if not last_user_questions:
        return question

    previous_topic = last_user_questions[0]
    return f"{previous_topic} -- {question}"
