"""Thin wrapper around the Groq chat completion API."""
from __future__ import annotations

from collections.abc import Iterator

from groq import Groq

from src.config import GROQ_API_KEY, GROQ_MODEL
from src.prompts import SYSTEM_PROMPT

_client: Groq | None = None


class LLMNotConfigured(RuntimeError):
    pass


def _get_client() -> Groq:
    global _client
    if not GROQ_API_KEY:
        raise LLMNotConfigured(
            "GROQ_API_KEY is not set. Add it to your .env file before using the LLM layer."
        )
    if _client is None:
        _client = Groq(api_key=GROQ_API_KEY)
    return _client


def _messages(user_message: str) -> list[dict]:
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_message},
    ]


def generate_answer(user_message: str) -> str:
    client = _get_client()
    response = client.chat.completions.create(
        model=GROQ_MODEL,
        messages=_messages(user_message),
        temperature=0.2,
    )
    return response.choices[0].message.content


def stream_answer(user_message: str) -> Iterator[str]:
    client = _get_client()
    stream = client.chat.completions.create(
        model=GROQ_MODEL,
        messages=_messages(user_message),
        temperature=0.2,
        stream=True,
    )
    for chunk in stream:
        delta = chunk.choices[0].delta.content
        if delta:
            yield delta
