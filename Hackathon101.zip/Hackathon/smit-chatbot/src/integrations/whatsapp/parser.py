"""
Converts Meta's raw WhatsApp Cloud API webhook payload into a normalized
internal structure. Nothing downstream of this module should need to know
the shape of Meta's JSON.
"""
from __future__ import annotations

from dataclasses import dataclass

SUPPORTED_TYPES = {"text"}
KNOWN_UNSUPPORTED_TYPES = {"image", "audio", "video", "document", "location", "sticker", "contacts", "reaction"}


@dataclass
class NormalizedMessage:
    channel: str
    user_id: str
    message_id: str
    message_type: str
    text: str | None
    timestamp: str


@dataclass
class NormalizedStatus:
    message_id: str
    recipient_id: str
    status: str
    timestamp: str


def parse_webhook_payload(payload: dict) -> tuple[list[NormalizedMessage], list[NormalizedStatus]]:
    """Returns (messages, statuses). Safe against malformed/partial
    payloads -- never raises for missing/unexpected fields, just skips
    what it can't parse."""
    messages: list[NormalizedMessage] = []
    statuses: list[NormalizedStatus] = []

    if not isinstance(payload, dict) or payload.get("object") != "whatsapp_business_account":
        return messages, statuses

    for entry in payload.get("entry", []) or []:
        for change in entry.get("changes", []) or []:
            value = change.get("value", {}) or {}

            for msg in value.get("messages", []) or []:
                normalized = _parse_message(msg)
                if normalized is not None:
                    messages.append(normalized)

            for status in value.get("statuses", []) or []:
                normalized_status = _parse_status(status)
                if normalized_status is not None:
                    statuses.append(normalized_status)

    return messages, statuses


def _parse_message(msg: dict) -> NormalizedMessage | None:
    try:
        message_id = msg["id"]
        sender = msg["from"]
        message_type = msg.get("type", "unknown")
        timestamp = msg.get("timestamp", "")
    except KeyError:
        return None

    text = None
    if message_type == "text":
        text = (msg.get("text") or {}).get("body")

    return NormalizedMessage(
        channel="whatsapp",
        user_id=sender,
        message_id=message_id,
        message_type=message_type,
        text=text,
        timestamp=timestamp,
    )


def _parse_status(status: dict) -> NormalizedStatus | None:
    try:
        return NormalizedStatus(
            message_id=status["id"],
            recipient_id=status.get("recipient_id", ""),
            status=status.get("status", "unknown"),
            timestamp=status.get("timestamp", ""),
        )
    except KeyError:
        return None
