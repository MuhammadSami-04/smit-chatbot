"""
WhatsApp-specific configuration. Only defines variables not already in
src/config.py (no duplication of CHROMA_PATH, GROQ_API_KEY, etc. -- the
WhatsApp layer never touches those directly; it only calls the agent).
"""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

from src.config import BASE_DIR

load_dotenv()

WHATSAPP_ACCESS_TOKEN = os.getenv("WHATSAPP_ACCESS_TOKEN", "")
WHATSAPP_PHONE_NUMBER_ID = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "")
WHATSAPP_BUSINESS_ACCOUNT_ID = os.getenv("WHATSAPP_BUSINESS_ACCOUNT_ID", "")
WHATSAPP_VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN", "")
WHATSAPP_API_VERSION = os.getenv("WHATSAPP_API_VERSION", "v21.0")

WHATSAPP_RATE_LIMIT_PER_MINUTE = int(os.getenv("WHATSAPP_RATE_LIMIT_PER_MINUTE", "10"))
WHATSAPP_DB_PATH = Path(os.getenv("WHATSAPP_DB_PATH", BASE_DIR / "data" / "whatsapp.db"))

_REQUIRED = {
    "WHATSAPP_ACCESS_TOKEN": WHATSAPP_ACCESS_TOKEN,
    "WHATSAPP_PHONE_NUMBER_ID": WHATSAPP_PHONE_NUMBER_ID,
    "WHATSAPP_BUSINESS_ACCOUNT_ID": WHATSAPP_BUSINESS_ACCOUNT_ID,
    "WHATSAPP_VERIFY_TOKEN": WHATSAPP_VERIFY_TOKEN,
}


def is_any_whatsapp_var_set() -> bool:
    """True if the deployer appears to be trying to configure WhatsApp at
    all. Used to decide whether to register the webhook blueprint -- so a
    pure web-chat deployment with no WhatsApp vars set is left untouched."""
    return any(_REQUIRED.values())


def validate_whatsapp_config() -> None:
    """Raise a clear, actionable error if WhatsApp is partially configured.
    Called only when at least one WhatsApp var is set (see
    is_any_whatsapp_var_set) -- never for a deployment that isn't using
    WhatsApp at all."""
    missing = [name for name, value in _REQUIRED.items() if not value]
    if missing:
        raise RuntimeError(
            "WhatsApp integration is partially configured. Missing required "
            f"environment variable(s): {', '.join(missing)}. Set all of "
            f"{', '.join(_REQUIRED)} in your .env file, or unset all of them "
            "to disable the WhatsApp integration entirely."
        )
