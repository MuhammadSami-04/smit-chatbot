"""
Communication with Meta's WhatsApp Cloud API. This module only sends/
receives HTTP -- no RAG logic, no prompt logic, no ChromaDB logic.
"""
from __future__ import annotations

import logging

import requests

from src.integrations.whatsapp.config import (
    WHATSAPP_ACCESS_TOKEN,
    WHATSAPP_API_VERSION,
    WHATSAPP_PHONE_NUMBER_ID,
)

logger = logging.getLogger(__name__)

_TIMEOUT_SECONDS = 15


def _api_url() -> str:
    return f"https://graph.facebook.com/{WHATSAPP_API_VERSION}/{WHATSAPP_PHONE_NUMBER_ID}/messages"


def send_text_message(recipient_wa_id: str, text: str) -> bool:
    """Sends a plain-text WhatsApp message. Returns True on success, False
    on failure (never raises -- callers should not crash the webhook flow
    over a Meta API failure)."""
    payload = {
        "messaging_product": "whatsapp",
        "to": recipient_wa_id,
        "type": "text",
        "text": {"body": text, "preview_url": False},
    }
    headers = {
        "Authorization": f"Bearer {WHATSAPP_ACCESS_TOKEN}",
        "Content-Type": "application/json",
    }

    try:
        response = requests.post(_api_url(), json=payload, headers=headers, timeout=_TIMEOUT_SECONDS)
        if response.status_code >= 400:
            logger.error("WhatsApp send failed: status=%s body=%s", response.status_code, response.text[:500])
            return False
        return True
    except requests.RequestException:
        logger.exception("WhatsApp send request failed")
        return False
