"""
Coordinates: incoming WhatsApp event -> dedup -> existing SMIT agent ->
response formatting -> WhatsApp client. This is the only integration
point with the agent; it calls the exact same `agent.handle_message` used
by the web chat, with no separate RAG/LLM/ChromaDB logic of its own.
"""
from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor

from src.agent import handle_message
from src.integrations.whatsapp import client, dedup
from src.integrations.whatsapp.formatter import (
    EMPTY_MESSAGE_REPLY,
    GENERIC_ERROR_MESSAGE,
    RATE_LIMIT_MESSAGE,
    UNSUPPORTED_TYPE_MESSAGE,
    format_agent_response,
)
from src.integrations.whatsapp.parser import NormalizedMessage, NormalizedStatus, parse_webhook_payload
from src.integrations.whatsapp.ratelimit import is_rate_limited

logger = logging.getLogger(__name__)

_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="whatsapp-worker")


def handle_webhook_payload(payload: dict) -> None:
    """Called by the webhook route. Parses the payload and schedules each
    message for background processing; the webhook route itself returns
    200 to Meta without waiting for this to finish."""
    messages, statuses = parse_webhook_payload(payload)

    for status in statuses:
        logger.info("whatsapp status event: message_id=%s status=%s", status.message_id, status.status)

    for message in messages:
        _executor.submit(_process_message_safely, message)


def _process_message_safely(message: NormalizedMessage) -> None:
    try:
        process_whatsapp_message(message)
    except Exception:
        logger.exception("Unhandled error processing whatsapp message_id=%s", message.message_id)


def process_whatsapp_message(message: NormalizedMessage) -> None:
    if not dedup.claim_message(message.message_id, message.user_id):
        logger.info("Duplicate whatsapp message_id=%s -- skipping", message.message_id)
        return

    try:
        if message.message_type != "text":
            client.send_text_message(message.user_id, UNSUPPORTED_TYPE_MESSAGE)
            dedup.mark_status(message.message_id, "unsupported_type")
            return

        text = (message.text or "").strip()
        if not text:
            client.send_text_message(message.user_id, EMPTY_MESSAGE_REPLY)
            dedup.mark_status(message.message_id, "empty_message")
            return

        if is_rate_limited(message.user_id):
            client.send_text_message(message.user_id, RATE_LIMIT_MESSAGE)
            dedup.mark_status(message.message_id, "rate_limited")
            return

        response = handle_message(session_id=message.user_id, message=text)
        reply_text = format_agent_response(response)
        sent = client.send_text_message(message.user_id, reply_text)
        dedup.mark_status(message.message_id, "answered" if sent else "send_failed")

    except Exception:
        logger.exception("Error while answering whatsapp message_id=%s", message.message_id)
        client.send_text_message(message.user_id, GENERIC_ERROR_MESSAGE)
        dedup.mark_status(message.message_id, "error")
