"""
Formats an existing AgentResponse (answer + Source list, produced by the
one shared src/agent.py) into WhatsApp-friendly plain text. This module
never invents a page, line, document, or URL -- it only renders fields
already present on the retrieved Source objects.
"""
from __future__ import annotations

from src.agent import AgentResponse, Source

UNSUPPORTED_TYPE_MESSAGE = "I currently support text questions only. Please send your question as text."
EMPTY_MESSAGE_REPLY = "I didn't receive any text -- please type your question."
GENERIC_ERROR_MESSAGE = "Sorry, I'm having trouble processing your request right now. Please try again shortly."
RATE_LIMIT_MESSAGE = "You're sending messages a bit fast -- please wait a moment before asking again."


def _format_source(source: Source) -> str:
    page = str(source.page_start) if source.page_start == source.page_end else f"{source.page_start}-{source.page_end}"
    lines = [
        f"\U0001F4C4 {source.document}",
        f"\U0001F4D6 Page: {page}",
        f"\U0001F4DD Lines: {source.line_start}–{source.line_end}",
        f"\U0001F4C2 Section: {source.section}",
    ]
    if source.source_url:
        lines.append(f"\U0001F517 Official Source: {source.source_url}")
    return "\n".join(lines)


def format_agent_response(response: AgentResponse) -> str:
    text = response.answer.strip()

    if not response.sources:
        return text

    if len(response.sources) == 1:
        return f"{text}\n\nSource:\n{_format_source(response.sources[0])}"

    sources_block = "\n\n".join(_format_source(s) for s in response.sources)
    return f"{text}\n\nSources:\n\n{sources_block}"
