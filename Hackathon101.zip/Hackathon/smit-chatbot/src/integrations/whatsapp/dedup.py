"""
Idempotency store for incoming WhatsApp messages. Meta may deliver the
same webhook event more than once; `message_id` is used as the dedup key
so the agent is never invoked twice for the same message.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from src.integrations.whatsapp.config import WHATSAPP_DB_PATH


def _connect() -> sqlite3.Connection:
    WHATSAPP_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(WHATSAPP_DB_PATH)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS processed_messages (
            message_id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            status TEXT NOT NULL
        )
        """
    )
    return conn


def claim_message(message_id: str, user_id: str) -> bool:
    """Atomically claim a message_id for processing. Returns True if this
    call is the first to see this message_id (safe to process), False if
    it was already claimed (duplicate delivery -- skip)."""
    conn = _connect()
    try:
        conn.execute(
            "INSERT INTO processed_messages (message_id, user_id, timestamp, status) VALUES (?, ?, ?, ?)",
            (message_id, user_id, datetime.now(timezone.utc).isoformat(), "processing"),
        )
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()


def mark_status(message_id: str, status: str) -> None:
    conn = _connect()
    try:
        conn.execute("UPDATE processed_messages SET status = ? WHERE message_id = ?", (status, message_id))
        conn.commit()
    finally:
        conn.close()
