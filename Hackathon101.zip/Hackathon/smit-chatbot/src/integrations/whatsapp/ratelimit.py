"""In-memory sliding-window rate limiter, keyed by WhatsApp user id.
Not persisted across restarts -- adequate for a hackathon deployment; a
production deployment with multiple worker processes would need a shared
store (e.g. Redis) instead."""
from __future__ import annotations

import time
from collections import defaultdict, deque

from src.integrations.whatsapp.config import WHATSAPP_RATE_LIMIT_PER_MINUTE

_WINDOW_SECONDS = 60
_hits: dict[str, deque] = defaultdict(deque)


def is_rate_limited(user_id: str) -> bool:
    now = time.time()
    hits = _hits[user_id]
    while hits and now - hits[0] > _WINDOW_SECONDS:
        hits.popleft()
    if len(hits) >= WHATSAPP_RATE_LIMIT_PER_MINUTE:
        return True
    hits.append(now)
    return False
