"""
Thin Flask Blueprint for the Meta WhatsApp Cloud API webhook. Contains no
RAG/LLM/ChromaDB/formatting logic -- everything is delegated to
src.integrations.whatsapp.service.
"""
from __future__ import annotations

import logging

from flask import Blueprint, jsonify, request

from src.integrations.whatsapp.config import WHATSAPP_VERIFY_TOKEN
from src.integrations.whatsapp.service import handle_webhook_payload

logger = logging.getLogger(__name__)

whatsapp_bp = Blueprint("whatsapp", __name__, url_prefix="/webhook")


@whatsapp_bp.route("/whatsapp", methods=["GET"])
def verify_webhook():
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge", "")

    if mode == "subscribe" and token == WHATSAPP_VERIFY_TOKEN:
        return challenge, 200
    return "Verification failed", 403


@whatsapp_bp.route("/whatsapp", methods=["POST"])
def receive_webhook():
    payload = request.get_json(force=True, silent=True)
    if payload is None:
        logger.warning("Received malformed (non-JSON) whatsapp webhook payload")
        return jsonify({"status": "ignored"}), 200

    try:
        handle_webhook_payload(payload)
    except Exception:
        # Never fail the webhook ack over a downstream problem -- Meta
        # will retry deliveries if we don't return 200 quickly.
        logger.exception("Error dispatching whatsapp webhook payload")

    return jsonify({"status": "received"}), 200
