"""Retrieval over the SMIT ChromaDB collection with a relevance threshold."""
from __future__ import annotations

from dataclasses import dataclass

from src.config import RETRIEVAL_THRESHOLD, TOP_K
from src.embeddings import embed_query
from src.vector_store import get_collection


@dataclass
class RetrievedChunk:
    chunk_id: str
    text: str
    document: str
    page_start: int
    page_end: int
    line_start: int
    line_end: int
    section: str
    source_url: str
    score: float  # cosine similarity, higher is more relevant
    distance: float


def _distance_to_similarity(distance: float) -> float:
    # Chroma's cosine "distance" is 1 - cosine_similarity.
    return 1.0 - distance


def retrieve(query: str, top_k: int = TOP_K) -> list[RetrievedChunk]:
    if not query or not query.strip():
        return []

    collection = get_collection()
    query_embedding = embed_query(query)
    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k,
        include=["documents", "metadatas", "distances"],
    )

    chunks: list[RetrievedChunk] = []
    ids = results["ids"][0]
    docs = results["documents"][0]
    metas = results["metadatas"][0]
    dists = results["distances"][0]

    for chunk_id, text, meta, dist in zip(ids, docs, metas, dists):
        similarity = _distance_to_similarity(dist)
        chunks.append(
            RetrievedChunk(
                chunk_id=chunk_id,
                text=text,
                document=meta["document"],
                page_start=meta["page_start"],
                page_end=meta["page_end"],
                line_start=meta["line_start"],
                line_end=meta["line_end"],
                section=meta["section"],
                source_url=meta.get("source_url", ""),
                score=similarity,
                distance=dist,
            )
        )
    return chunks


def retrieve_above_threshold(
    query: str, top_k: int = TOP_K, threshold: float = RETRIEVAL_THRESHOLD
) -> list[RetrievedChunk]:
    """Return only chunks whose similarity clears the configured threshold.
    An empty result means the knowledge base has insufficient context for
    this query -- the caller should refuse rather than guess."""
    return [c for c in retrieve(query, top_k=top_k) if c.score >= threshold]


def _format_result(i: int, chunk: RetrievedChunk) -> str:
    return (
        f"{'=' * 50}\n"
        f"RESULT {i}\n"
        f"{'=' * 50}\n\n"
        f"Text:\n{chunk.text}\n\n"
        f"Document:\n{chunk.document}\n\n"
        f"Page:\n{chunk.page_start}"
        + (f"-{chunk.page_end}" if chunk.page_end != chunk.page_start else "")
        + "\n\n"
        f"Lines:\n{chunk.line_start}-{chunk.line_end}\n\n"
        f"Section:\n{chunk.section}\n\n"
        f"Score:\n{chunk.score:.4f}\n\n"
        f"Chunk ID:\n{chunk.chunk_id}\n"
    )


def _interactive_loop() -> None:
    print("SMIT Knowledge Base Retriever")
    print(f"(top_k={TOP_K}, threshold={RETRIEVAL_THRESHOLD})")
    print("Type a question, or 'quit' to exit.\n")
    while True:
        try:
            query = input("Enter your question: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if query.lower() in {"quit", "exit"}:
            break
        if not query:
            continue

        results = retrieve(query, top_k=TOP_K)
        if not results:
            print("\nNo results returned.\n")
            continue

        above_threshold = [r for r in results if r.score >= RETRIEVAL_THRESHOLD]
        print()
        for i, chunk in enumerate(results, start=1):
            print(_format_result(i, chunk))

        if not above_threshold:
            print(
                f"[No chunk cleared the relevance threshold ({RETRIEVAL_THRESHOLD}). "
                "This question would be flagged as insufficient context.]\n"
            )


if __name__ == "__main__":
    _interactive_loop()
