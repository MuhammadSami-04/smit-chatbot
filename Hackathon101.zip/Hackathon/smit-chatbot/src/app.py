"""Flask app exposing the SMIT Assistant chat API and a simple streaming UI."""
from __future__ import annotations

import json
import logging
import os
import secrets
import uuid
from pathlib import Path

from flask import Flask, Response, jsonify, render_template, request, session

from src.agent import (
    NOT_FOUND_MESSAGE,
    handle_message,
    prepare_streaming_context,
    sources_from_answer,
)
from src.config import COLLECTION_NAME
from src.llm import LLMNotConfigured, stream_answer
from src import memory
from src.integrations.whatsapp.config import is_any_whatsapp_var_set, validate_whatsapp_config

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__, template_folder="../templates", static_folder="../static")
app.secret_key = secrets.token_hex(16)

_whatsapp_enabled = False
if is_any_whatsapp_var_set():
    validate_whatsapp_config()  # raises a clear error if only partially configured
    from src.integrations.whatsapp.webhook import whatsapp_bp

    app.register_blueprint(whatsapp_bp)
    _whatsapp_enabled = True
    logger.info("WhatsApp integration enabled at /webhook/whatsapp")
else:
    logger.info("WhatsApp environment variables not set -- WhatsApp integration disabled")


@app.after_request
def add_no_cache(response):
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


def _session_id() -> str:
    if "session_id" not in session:
        session["session_id"] = uuid.uuid4().hex
    return session["session_id"]


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/health")
def health():
    rag_status = "unavailable"
    try:
        from src.vector_store import get_collection

        count = get_collection().count()
        rag_status = "available" if count > 0 else "empty"
    except Exception:
        logger.exception("health check: RAG unavailable")

    return jsonify(
        {
            "status": "ok",
            "rag": rag_status,
            "chroma_collection": COLLECTION_NAME,
            "whatsapp": "configured" if _whatsapp_enabled else "disabled",
        }
    )


@app.route("/api/whatsapp/config", methods=["POST"])
def whatsapp_config():
    """Save WhatsApp credentials to .env file."""
    try:
        data = request.get_json(force=True, silent=True) or {}
        access_token = str(data.get("access_token", "")).strip()
        phone_id = str(data.get("phone_number_id", "")).strip()
        business_id = str(data.get("business_account_id", "")).strip()
        verify_token = str(data.get("verify_token", "")).strip()

        if not all([access_token, phone_id, business_id, verify_token]):
            return jsonify({"error": "All four credentials are required."}), 400

        env_path = Path(__file__).resolve().parent.parent / ".env"
        env_content = env_path.read_text() if env_path.exists() else ""

        updates = {
            "WHATSAPP_ACCESS_TOKEN": access_token,
            "WHATSAPP_PHONE_NUMBER_ID": phone_id,
            "WHATSAPP_BUSINESS_ACCOUNT_ID": business_id,
            "WHATSAPP_VERIFY_TOKEN": verify_token,
        }

        for key, value in updates.items():
            if f"{key}=" in env_content:
                lines = env_content.splitlines()
                for i, line in enumerate(lines):
                    if line.startswith(f"{key}="):
                        lines[i] = f"{key}={value}"
                        break
                env_content = "\n".join(lines) + "\n"
            else:
                env_content += f"\n{key}={value}"

        env_path.write_text(env_content)

        os.environ["WHATSAPP_ACCESS_TOKEN"] = access_token
        os.environ["WHATSAPP_PHONE_NUMBER_ID"] = phone_id
        os.environ["WHATSAPP_BUSINESS_ACCOUNT_ID"] = business_id
        os.environ["WHATSAPP_VERIFY_TOKEN"] = verify_token

        logger.info("WhatsApp credentials saved to .env and loaded into environment")
        return jsonify({"success": True, "message": "Credentials saved. Restart server to activate WhatsApp."})
    except Exception:
        logger.exception("failed to save WhatsApp config")
        return jsonify({"error": "Failed to save credentials."}), 500


@app.route("/api/chat", methods=["POST"])
def chat():
    try:
        data = request.get_json(force=True, silent=True) or {}
        message = str(data.get("message", ""))[:2000]
        debug = bool(data.get("debug", False))
        if not message.strip():
            return jsonify({"error": "Empty question."}), 400

        session_id = _session_id()
        response = handle_message(session_id, message, debug=debug)
        payload = {
            "answer": response.answer,
            "sources": [s.__dict__ for s in response.sources],
            "confidence": response.confidence,
            "tool_used": response.tool_used,
        }
        if debug and response.debug:
            payload["debug"] = response.debug
        return jsonify(payload)
    except Exception:
        logger.exception("chat endpoint failed")
        return jsonify({"error": "Something went wrong processing your question. Please try again."}), 500


@app.route("/api/chat/stream", methods=["POST"])
def chat_stream():
    data = request.get_json(force=True, silent=True) or {}
    message = str(data.get("message", ""))[:2000]
    debug = bool(data.get("debug", False))
    if not message.strip():
        return jsonify({"error": "Empty question."}), 400

    session_id = _session_id()
    memory.add_turn(session_id, "user", message)

    def event_stream():
        try:
            relevant, user_message, debug_info = prepare_streaming_context(session_id, message, debug=debug)
            if user_message is None:
                yield f"data: {json.dumps({'token': NOT_FOUND_MESSAGE})}\n\n"
                done_payload = {"done": True, "sources": [], "confidence": 0}
                if debug_info:
                    done_payload["debug"] = debug_info
                yield "data: " + json.dumps(done_payload) + "\n\n"
                memory.add_turn(session_id, "assistant", NOT_FOUND_MESSAGE)
                return
            full_answer = ""
            try:
                for token in stream_answer(user_message):
                    full_answer += token
                    yield f"data: {json.dumps({'token': token})}\n\n"
            except LLMNotConfigured:
                msg = "LLM not configured. Set GROQ_API_KEY in .env to enable generated answers."
                yield f"data: {json.dumps({'token': msg})}\n\n"
                full_answer = msg

            sources = sources_from_answer(full_answer, relevant)
            top_score = max((c.score for c in relevant), default=0.0)
            memory.add_turn(session_id, "assistant", full_answer)
            done_payload = {
                "done": True,
                "sources": [s.__dict__ for s in sources],
                "confidence": round(top_score, 4),
            }
            if debug_info:
                done_payload["debug"] = debug_info
            yield "data: " + json.dumps(done_payload) + "\n\n"
        except Exception:
            logger.exception("stream failed")
            yield f"data: {json.dumps({'error': 'Something went wrong. Please try again.'})}\n\n"

    return Response(event_stream(), mimetype="text/event-stream")


if __name__ == "__main__":
    app.run(debug=True, port=5050)
