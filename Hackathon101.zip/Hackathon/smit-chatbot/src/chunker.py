"""
Section-aware chunking of extracted PDF lines.

Chunk boundaries always fall on line boundaries -- a single PDF line's text
is never split across two chunks, since the line is the atomic provenance
unit. Chunking prefers to break at section-heading boundaries; a section
larger than the target size is split into multiple chunks with a small
line-level overlap so nearby chunks share context.

Token counts are approximated as `len(text.split()) * 1.3` (no tokenizer
dependency was added for this stage); this is a heuristic sizing signal,
not an exact token count.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from src.config import CHUNK_OVERLAP_TOKENS, CHUNK_SIZE_TOKENS, DOCUMENT_NAME
from src.pdf_loader import ExtractedLine

WORDS_TO_TOKENS = 1.3
URL_RE = re.compile(r"https?://[^\s)]+")


@dataclass
class Chunk:
    chunk_id: str
    text: str
    document: str
    page_start: int
    page_end: int
    line_start: int
    line_end: int
    section: str
    source_url: str = ""


def _approx_tokens(text: str) -> float:
    return len(text.split()) * WORDS_TO_TOKENS


def _group_by_section(lines: list[ExtractedLine]) -> list[list[ExtractedLine]]:
    groups: list[list[ExtractedLine]] = []
    current_section = None
    current_group: list[ExtractedLine] = []
    for line in lines:
        if line.section != current_section:
            if current_group:
                groups.append(current_group)
            current_group = []
            current_section = line.section
        current_group.append(line)
    if current_group:
        groups.append(current_group)
    return groups


def _lines_for_overlap(lines: list[ExtractedLine], overlap_tokens: int) -> list[ExtractedLine]:
    if overlap_tokens <= 0:
        return []
    tail: list[ExtractedLine] = []
    tokens = 0.0
    for line in reversed(lines):
        line_tokens = _approx_tokens(line.text)
        if tokens + line_tokens > overlap_tokens and tail:
            break
        tail.insert(0, line)
        tokens += line_tokens
    return tail


def _make_chunk(lines: list[ExtractedLine], index: int) -> Chunk:
    text = "\n".join(f"{ln.text}" for ln in lines if ln.text)
    page_start = lines[0].page
    page_end = lines[-1].page
    line_start = lines[0].line_number
    line_end = lines[-1].line_number
    section = lines[0].section
    url_match = URL_RE.search(text)
    source_url = url_match.group(0).rstrip(".,") if url_match else ""
    chunk_id = (
        f"{DOCUMENT_NAME.rsplit('.', 1)[0]}"
        f"_p{page_start:02d}-{page_end:02d}"
        f"_l{line_start:04d}-{line_end:04d}"
        f"_c{index:03d}"
    )
    return Chunk(
        chunk_id=chunk_id,
        text=text,
        document=DOCUMENT_NAME,
        page_start=page_start,
        page_end=page_end,
        line_start=line_start,
        line_end=line_end,
        section=section,
        source_url=source_url,
    )


def create_chunks(
    lines: list[ExtractedLine],
    chunk_size_tokens: int = CHUNK_SIZE_TOKENS,
    chunk_overlap_tokens: int = CHUNK_OVERLAP_TOKENS,
) -> list[Chunk]:
    chunks: list[Chunk] = []
    index = 1

    for section_lines in _group_by_section(lines):
        buffer: list[ExtractedLine] = []
        buffer_tokens = 0.0

        for line in section_lines:
            line_tokens = _approx_tokens(line.text) if line.text else 0.0

            if buffer and buffer_tokens + line_tokens > chunk_size_tokens:
                chunks.append(_make_chunk(buffer, index))
                index += 1
                overlap = _lines_for_overlap(buffer, chunk_overlap_tokens)
                buffer = list(overlap)
                buffer_tokens = sum(_approx_tokens(ln.text) for ln in buffer)

            buffer.append(line)
            buffer_tokens += line_tokens

        if buffer and any(ln.text for ln in buffer):
            chunks.append(_make_chunk(buffer, index))
            index += 1

    return chunks
