"""
Single orchestrator that routes a user message to knowledge search, the
eligibility tool, the complaint tool, or a combination -- then produces a
source-aware response.

Citation metadata is always taken verbatim from retrieved chunk metadata;
the LLM only ever refers to sources by [S1]/[S2] labels, never by writing
its own page/line numbers.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from src import memory
from src.config import RETRIEVAL_THRESHOLD, TOP_K
from src.llm import LLMNotConfigured, generate_answer
from src.prompts import build_user_message, format_context_block
from src.retriever import RetrievedChunk, retrieve
from src.tools import ComplaintValidationError, check_eligibility, create_complaint

COMPLAINT_RE = re.compile(r"\b(complain|complaint|file a (query|complaint)|report an issue)\b", re.IGNORECASE)
SOURCE_TAG_RE = re.compile(r"[\[【]S(\d+)[\]】]")
COMPLAINT_SLOT_RE = re.compile(r"\b(name|contact|category|description)\s*[:=]", re.IGNORECASE)

ELIGIBILITY_RE = re.compile(r"\b(am i eligible|eligib(le|ility)|can i (apply|join|enroll))\b", re.IGNORECASE)
AGE_RE = re.compile(r"(\d{1,2})\s*(?:years?\s*old|yo\b|year-old)", re.IGNORECASE)
EDUCATION_KEYWORDS = [
    "matriculation", "matric", "10th grade", "o-level", "o level",
    "intermediate", "a-level", "a level", "bachelor", "primary", "middle school",
]

NOT_FOUND_MESSAGE = "I couldn't find that information in the SMIT knowledge base."

_pending_complaints: dict[str, dict] = {}


@dataclass
class Source:
    document: str
    page_start: int
    page_end: int
    line_start: int
    line_end: int
    section: str
    source_url: str
    score: float


@dataclass
class AgentResponse:
    answer: str
    sources: list[Source] = field(default_factory=list)
    confidence: float = 0.0
    tool_used: str = "knowledge_search"
    debug: dict | None = None


def _source_from_chunk(chunk: RetrievedChunk) -> Source:
    return Source(
        document=chunk.document,
        page_start=chunk.page_start,
        page_end=chunk.page_end,
        line_start=chunk.line_start,
        line_end=chunk.line_end,
        section=chunk.section,
        source_url=chunk.source_url,
        score=chunk.score,
    )


def _answer_from_knowledge_base(session_id: str, question: str, debug: bool = False) -> AgentResponse:
    from src.prompts import is_urdu, translate_to_english

    search_text = question
    if is_urdu(question):
        search_text = translate_to_english(question) or question

    search_query = memory.build_search_query(session_id, search_text)
    all_results = retrieve(search_query, top_k=TOP_K)
    relevant = [c for c in all_results if c.score >= RETRIEVAL_THRESHOLD]

    debug_info = None
    if debug:
        debug_info = {
            "query": question,
            "search_query": search_query,
            "retrieved": [
                {
                    "chunk_id": c.chunk_id,
                    "score": round(c.score, 4),
                    "page": f"{c.page_start}-{c.page_end}",
                    "lines": f"{c.line_start}-{c.line_end}",
                    "section": c.section,
                }
                for c in all_results
            ],
            "threshold": RETRIEVAL_THRESHOLD,
        }

    if not relevant:
        return AgentResponse(answer=NOT_FOUND_MESSAGE, sources=[], confidence=0.0, debug=debug_info)

    context_blocks = [format_context_block(i + 1, c.text) for i, c in enumerate(relevant)]
    history_snippet = memory.get_history_snippet(session_id)
    user_message = build_user_message(question, context_blocks, history_snippet)

    try:
        raw_answer = generate_answer(user_message)
    except LLMNotConfigured:
        raw_answer = _extractive_fallback(relevant)

    # No [S#] tags means the model didn't actually draw on any passage (e.g.
    # it wrote a plain-language refusal) -- attach no sources rather than
    # dumping every retrieved chunk as if it were used.
    used_indices = {int(n) for n in SOURCE_TAG_RE.findall(raw_answer)}
    cited_sources = [_source_from_chunk(relevant[i - 1]) for i in sorted(used_indices) if i - 1 < len(relevant)]

    clean_answer = SOURCE_TAG_RE.sub("", raw_answer).strip()
    top_score = max(c.score for c in relevant)

    return AgentResponse(
        answer=clean_answer,
        sources=cited_sources,
        confidence=round(top_score, 4),
        debug=debug_info,
    )


def _extractive_fallback(chunks: list[RetrievedChunk]) -> str:
    """Used only when no LLM API key is configured, so retrieval can still
    be demoed end-to-end. Never invents facts -- just surfaces retrieved text."""
    parts = [f"[S{i + 1}] {c.text}" for i, c in enumerate(chunks)]
    return (
        "(LLM not configured -- showing retrieved passages directly)\n\n"
        + "\n\n".join(parts)
    )


def prepare_streaming_context(
    session_id: str, question: str, debug: bool = False
) -> tuple[list[RetrievedChunk], str | None, dict | None]:
    """Returns (relevant_chunks, llm_user_message, debug_info). llm_user_message
    is None if no chunk clears the relevance threshold -- the caller should
    send NOT_FOUND_MESSAGE directly instead of streaming from the LLM."""
    from src.prompts import is_urdu, translate_to_english

    search_text = question
    if is_urdu(question):
        search_text = translate_to_english(question) or question

    search_query = memory.build_search_query(session_id, search_text)
    all_results = retrieve(search_query, top_k=TOP_K)
    relevant = [c for c in all_results if c.score >= RETRIEVAL_THRESHOLD]

    debug_info = None
    if debug:
        debug_info = {
            "query": question,
            "search_query": search_query,
            "retrieved": [
                {
                    "chunk_id": c.chunk_id,
                    "score": round(c.score, 4),
                    "page": f"{c.page_start}-{c.page_end}",
                    "lines": f"{c.line_start}-{c.line_end}",
                    "section": c.section,
                }
                for c in all_results
            ],
            "threshold": RETRIEVAL_THRESHOLD,
        }

    if not relevant:
        return [], None, debug_info
    context_blocks = [format_context_block(i + 1, c.text) for i, c in enumerate(relevant)]
    history_snippet = memory.get_history_snippet(session_id)
    user_message = build_user_message(question, context_blocks, history_snippet)
    return relevant, user_message, debug_info


def sources_from_answer(answer_text: str, relevant: list[RetrievedChunk]) -> list[Source]:
    # See the matching comment in _answer_from_knowledge_base: no tags means
    # nothing was actually cited, so attach no sources.
    used_indices = {int(n) for n in SOURCE_TAG_RE.findall(answer_text)}
    return [_source_from_chunk(relevant[i - 1]) for i in sorted(used_indices) if i - 1 < len(relevant)]


def _try_eligibility(message: str) -> AgentResponse | None:
    """Returns a tool response only when the message is a personal
    eligibility check with an extractable age (e.g. "Am I eligible at 12
    with a matric certificate?"); otherwise returns None so the message
    falls through to normal knowledge search (e.g. general "What is the
    eligibility for SMIT courses?")."""
    if not ELIGIBILITY_RE.search(message):
        return None
    age_match = AGE_RE.search(message)
    if not age_match:
        return None

    age = int(age_match.group(1))
    education_level = "not specified"
    for kw in EDUCATION_KEYWORDS:
        if kw in message.lower():
            education_level = kw
            break

    result = check_eligibility(course="(unspecified)", education_level=education_level, age=age)
    if result.eligible is None:
        answer = result.reasons[0]
        sources = []
    else:
        verdict = "You appear to be eligible." if result.eligible else "You do not appear to be eligible."
        answer = verdict + "\n\n" + "\n".join(f"- {r}" for r in result.reasons) + f"\n\n{result.course_specific_note}"
        sources = (
            [
                Source(
                    document="SMIT_Master_Knowledge_Base.pdf",
                    page_start=result.source_page,
                    page_end=result.source_page,
                    line_start=int(result.source_lines.split("-")[0]),
                    line_end=int(result.source_lines.split("-")[1]),
                    section="Eligibility Rules",
                    source_url="",
                    score=1.0,
                )
            ]
            if result.source_page
            else []
        )

    return AgentResponse(answer=answer, sources=sources, confidence=1.0, tool_used="eligibility_tool")


def _handle_complaint(session_id: str, message: str) -> AgentResponse:
    pending = _pending_complaints.setdefault(session_id, {})
    # Extremely lightweight slot filling: look for "name:", "contact:", etc.
    for field_name in ("name", "contact", "category", "description"):
        match = re.search(rf"{field_name}\s*[:=]\s*(.+)", message, re.IGNORECASE)
        if match:
            pending[field_name] = match.group(1).strip()

    if "description" not in pending and not COMPLAINT_RE.search(message) is None:
        pending.setdefault("description", message)

    missing = [f for f in ("name", "contact", "category", "description") if f not in pending]
    if missing:
        return AgentResponse(
            answer=(
                "I can help you submit a complaint/query. Please provide the following "
                f"(missing: {', '.join(missing)}):\n"
                "name: <your name>\ncontact: <phone or email>\ncategory: <admission/technical/course/portal/certificate/other>\ndescription: <details>"
            ),
            sources=[],
            confidence=1.0,
            tool_used="complaint_tool",
        )

    try:
        reference_id = create_complaint(**pending)
    except ComplaintValidationError as e:
        return AgentResponse(answer=f"Could not submit complaint: {e}", sources=[], tool_used="complaint_tool")
    finally:
        _pending_complaints.pop(session_id, None)

    return AgentResponse(
        answer=f"Your complaint has been submitted.\n\nReference ID:\n{reference_id}",
        sources=[],
        confidence=1.0,
        tool_used="complaint_tool",
    )


def handle_message(session_id: str, message: str, debug: bool = False) -> AgentResponse:
    message = message.strip()
    if not message:
        return AgentResponse(answer="Please type a question.", sources=[])

    memory.add_turn(session_id, "user", message)

    in_pending_flow = session_id in _pending_complaints
    continues_pending_flow = in_pending_flow and bool(COMPLAINT_SLOT_RE.search(message))
    is_new_complaint = bool(COMPLAINT_RE.search(message))

    if in_pending_flow and not continues_pending_flow and not is_new_complaint:
        # user abandoned the complaint flow (asked something else) -- drop
        # the pending state instead of trapping every future message in it.
        _pending_complaints.pop(session_id, None)
        in_pending_flow = False

    looks_like_question = "?" in message or bool(
        re.search(r"\b(what|how|where|when|which|eligib|require|course|fee|admission)\b", message, re.IGNORECASE)
    )

    if is_new_complaint and not continues_pending_flow and looks_like_question:
        # combined request: e.g. "what are the requirements, and I also want
        # to file a complaint" -- answer from the knowledge base AND open
        # the complaint tool's slot-filling flow.
        kb_response = _answer_from_knowledge_base(session_id, message, debug=debug)
        complaint_response = _handle_complaint(session_id, message)
        response = AgentResponse(
            answer=f"{kb_response.answer}\n\n---\n\n{complaint_response.answer}",
            sources=kb_response.sources,
            confidence=kb_response.confidence,
            tool_used="knowledge_search+complaint_tool",
            debug=kb_response.debug,
        )
    elif is_new_complaint or continues_pending_flow:
        response = _handle_complaint(session_id, message)
    else:
        eligibility_response = _try_eligibility(message)
        if eligibility_response is not None:
            response = eligibility_response
        else:
            response = _answer_from_knowledge_base(session_id, message, debug=debug)

    memory.add_turn(session_id, "assistant", response.answer)
    return response
