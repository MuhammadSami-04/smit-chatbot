"""
Tool layer used by the agent orchestrator.

- search_smit_knowledge: retrieval over the vector store (with citations).
- check_eligibility: deterministic check against the actual eligibility
  rule text stored in the knowledge base (parsed at call time, not
  hardcoded), so the tool never invents a rule the PDF doesn't state.
- create_complaint: stores a complaint/query in a local SQLite database
  and returns a reference ID.
"""
from __future__ import annotations

import re
import sqlite3
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone

from src.config import COMPLAINTS_DB_PATH, RETRIEVAL_THRESHOLD, TOP_K
from src.retriever import RetrievedChunk, retrieve
from src.vector_store import get_collection


# ---------------------------------------------------------------------------
# Tool 1: Knowledge search
# ---------------------------------------------------------------------------
def search_smit_knowledge(query: str, top_k: int = TOP_K) -> list[RetrievedChunk]:
    return retrieve(query, top_k=top_k)


# ---------------------------------------------------------------------------
# Tool 2: Eligibility check
# ---------------------------------------------------------------------------
@dataclass
class EligibilityResult:
    eligible: bool | None  # None = knowledge base does not have enough info
    reasons: list[str]
    course_specific_note: str
    source_page: int | None
    source_lines: str | None


_MIN_AGE_RE = re.compile(r"at least (\d+) years of age", re.IGNORECASE)
_MIN_EDU_KEYWORDS = ("matriculation", "matric", "10th grade", "o-level")


def _get_eligibility_chunk() -> RetrievedChunk | None:
    collection = get_collection()
    res = collection.get(where={"section": "Eligibility Rules"}, include=["documents", "metadatas"])
    if not res["ids"]:
        return None
    meta = res["metadatas"][0]
    return RetrievedChunk(
        chunk_id=res["ids"][0],
        text=res["documents"][0],
        document=meta["document"],
        page_start=meta["page_start"],
        page_end=meta["page_end"],
        line_start=meta["line_start"],
        line_end=meta["line_end"],
        section=meta["section"],
        source_url=meta.get("source_url", ""),
        score=1.0,
        distance=0.0,
    )


def check_eligibility(course: str, education_level: str, age: int) -> EligibilityResult:
    chunk = _get_eligibility_chunk()
    if chunk is None:
        return EligibilityResult(
            eligible=None,
            reasons=["Eligibility rules were not found in the knowledge base."],
            course_specific_note="",
            source_page=None,
            source_lines=None,
        )

    text_lower = chunk.text.lower()
    reasons: list[str] = []
    eligible = True

    age_match = _MIN_AGE_RE.search(chunk.text)
    if age_match:
        min_age = int(age_match.group(1))
        if age < min_age:
            eligible = False
            reasons.append(f"Minimum age per the knowledge base is {min_age}; you entered {age}.")
        else:
            reasons.append(f"Age requirement met (minimum {min_age}).")
    else:
        reasons.append("Age rule not found in the knowledge base -- cannot verify age eligibility.")

    education_lower = education_level.lower()
    edu_ok = any(k in education_lower for k in _MIN_EDU_KEYWORDS) or any(
        k in text_lower and k in education_lower for k in _MIN_EDU_KEYWORDS
    )
    # Accept anything at-or-above matric (heuristic: reject only explicit "primary"/"middle school")
    if education_lower in {"primary", "middle school", "no formal education"}:
        eligible = False
        reasons.append("Minimum education per the knowledge base is Matriculation (10th grade) or O-Level.")
    else:
        reasons.append("Education requirement appears to meet the Matriculation/O-Level minimum stated in the knowledge base.")

    course_note = (
        f"Course-specific prerequisites for '{course}' are not itemized in this general "
        "eligibility section -- check the specific course curriculum, or ask about that course directly."
    )

    return EligibilityResult(
        eligible=eligible,
        reasons=reasons,
        course_specific_note=course_note,
        source_page=chunk.page_start,
        source_lines=f"{chunk.line_start}-{chunk.line_end}",
    )


# ---------------------------------------------------------------------------
# Tool 3: Complaint / query submission
# ---------------------------------------------------------------------------
VALID_CATEGORIES = {"admission", "technical", "course", "portal", "certificate", "other"}


class ComplaintValidationError(ValueError):
    pass


def _init_db() -> None:
    COMPLAINTS_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(COMPLAINTS_DB_PATH)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS complaints (
            reference_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            contact TEXT NOT NULL,
            category TEXT NOT NULL,
            description TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


def create_complaint(name: str, contact: str, category: str, description: str) -> str:
    name = (name or "").strip()
    contact = (contact or "").strip()
    category = (category or "").strip().lower()
    description = (description or "").strip()

    if not name:
        raise ComplaintValidationError("Name is required.")
    if not contact:
        raise ComplaintValidationError("Contact information (phone or email) is required.")
    if not description:
        raise ComplaintValidationError("Description is required.")
    if category not in VALID_CATEGORIES:
        category = "other"

    _init_db()
    year = datetime.now(timezone.utc).year
    reference_id = f"SMIT-{year}-{uuid.uuid4().hex[:5].upper()}"

    conn = sqlite3.connect(COMPLAINTS_DB_PATH)
    conn.execute(
        "INSERT INTO complaints (reference_id, name, contact, category, description, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (reference_id, name, contact, category, description, datetime.now(timezone.utc).isoformat()),
    )
    conn.commit()
    conn.close()
    return reference_id
