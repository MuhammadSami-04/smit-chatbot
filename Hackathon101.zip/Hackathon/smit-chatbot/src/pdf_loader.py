"""
Extracts SMIT_Master_Knowledge_Base.pdf while preserving the PDF's own
authoritative line numbers and page numbers.

Structure of the source PDF (verified by direct inspection, not assumed):
  - Page 1 is a cover page with no numbered lines.
  - Every subsequent page repeats a 2-line running header
    ("SMIT Master Knowledge Base" / "Saylani Mass IT Training") near the
    top (y ~ 32-45) and a footer ("... Confidential Reference Document" /
    "Page X of Y") near the bottom (y ~ 804-815). Both are stripped via a
    clip rectangle, not by text matching, so wording changes can't leak
    them into content.
  - Content lines are each prefixed with a strictly sequential integer
    (1, 2, 3, ... 1147) with no prefix/suffix. Sometimes the number and its
    text share one physical PDF line (e.g. "44 Current Admissions"),
    sometimes the number is alone and the text follows on subsequent
    physical lines until the next sequential number appears. A token is
    only accepted as a line-number marker if it equals previous+1 -- this
    avoids misreading a table value (a year, a percentage) as a marker.
  - Section headings render at font size >= 11pt (Helvetica-Bold); normal
    body text renders at 9.3pt. This is used to detect section titles
    instead of guessing from text shape.

This module performs no renumbering: `line_number` and `page` always come
directly from the PDF's own markers/footers.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import pymupdf as fitz

HEADING_FONT_SIZE_THRESHOLD = 11.0
HEADER_BAND_BOTTOM = 50
FOOTER_BAND_TOP_MARGIN = 45


@dataclass
class ExtractedLine:
    document: str
    page: int
    line_number: int
    text: str
    is_heading: bool
    section: str
    font_size: float = 0.0


def _iter_visual_lines(page: fitz.Page):
    """Yield (text, max_font_size) for each visual line, header/footer excluded."""
    h, w = page.rect.height, page.rect.width
    clip = fitz.Rect(0, HEADER_BAND_BOTTOM, w, h - FOOTER_BAND_TOP_MARGIN)
    page_dict = page.get_text("dict", clip=clip)
    for block in page_dict["blocks"]:
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            spans = line["spans"]
            if not spans:
                continue
            text = "".join(s["text"] for s in spans).strip()
            if not text:
                continue
            max_font = max(s["size"] for s in spans)
            yield text, max_font


def extract_lines(pdf_path: Path, document_name: str) -> list[ExtractedLine]:
    """Extract every numbered line in the PDF, in order, with page + section."""
    doc = fitz.open(pdf_path)

    raw_entries: list[list] = []  # [line_number, page, text, max_font]
    prev_num = 0
    marker_re = re.compile(r"^(\d{1,4})\s*(.*)$")

    for page_index in range(len(doc)):
        page = doc[page_index]
        page_number = page_index + 1
        for text, font_size in _iter_visual_lines(page):
            match = marker_re.match(text)
            if match and int(match.group(1)) == prev_num + 1:
                n = int(match.group(1))
                content = match.group(2).strip()
                raw_entries.append([n, page_number, content, font_size])
                prev_num = n
            else:
                if raw_entries:
                    raw_entries[-1][2] = (raw_entries[-1][2] + " " + text).strip()
                    raw_entries[-1][3] = max(raw_entries[-1][3], font_size)

    doc.close()

    if not raw_entries:
        raise RuntimeError(
            f"No sequential line markers were found in {pdf_path}. "
            "The PDF's line-numbering scheme could not be recovered."
        )

    _validate_sequence(raw_entries, pdf_path)

    lines: list[ExtractedLine] = []
    current_section = "Front Matter"
    for n, page_number, content, font_size in raw_entries:
        is_heading = font_size >= HEADING_FONT_SIZE_THRESHOLD and bool(content)
        if is_heading and n > 3:
            # lines 1-3 are the cover-style title repeated on p.2, not a section
            current_section = content
        lines.append(
            ExtractedLine(
                document=document_name,
                page=page_number,
                line_number=n,
                text=content,
                is_heading=is_heading,
                section=current_section,
                font_size=font_size,
            )
        )
    return lines


def _validate_sequence(raw_entries: list[list], pdf_path: Path) -> None:
    numbers = [e[0] for e in raw_entries]
    expected = list(range(numbers[0], numbers[-1] + 1))
    if numbers != expected:
        missing = sorted(set(expected) - set(numbers))
        raise RuntimeError(
            f"Line-number sequence in {pdf_path} is not contiguous. "
            f"Missing line numbers: {missing[:20]}{'...' if len(missing) > 20 else ''}. "
            "Refusing to fabricate approximate line numbers -- fix the PDF or the "
            "extraction logic before proceeding."
        )


def get_page_count(pdf_path: Path) -> int:
    doc = fitz.open(pdf_path)
    n = len(doc)
    doc.close()
    return n
