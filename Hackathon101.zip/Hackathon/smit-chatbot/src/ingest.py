"""
Main ingestion entrypoint.

Usage:
    python -m src.ingest            # incremental upsert (safe to re-run)
    python -m src.ingest --rebuild  # drop and recreate the collection first
"""
from __future__ import annotations

import argparse
import logging
import sys

from src.chunker import create_chunks
from src.config import DOCUMENT_NAME, PDF_PATH
from src.embeddings import embed_texts
from src.pdf_loader import extract_lines
from src.vector_store import (
    get_client,
    get_collection,
    prune_stale_ids,
    rebuild_collection,
    upsert_chunks,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def run(rebuild: bool = False) -> None:
    print("=" * 40)
    print("SMIT RAG INGESTION")
    print("=" * 40)
    print()
    print("Document:")
    print(DOCUMENT_NAME)
    print()

    if not PDF_PATH.exists():
        print(f"Status:\nFAILED - PDF not found at {PDF_PATH}")
        sys.exit(1)

    logger.info("Extracting lines from %s", PDF_PATH)
    lines = extract_lines(PDF_PATH, DOCUMENT_NAME)
    pages_processed = max(ln.page for ln in lines)
    sections = {ln.section for ln in lines}

    logger.info("Chunking %d lines", len(lines))
    chunks = create_chunks(lines)

    logger.info("Generating embeddings for %d chunks", len(chunks))
    embeddings = embed_texts([c.text for c in chunks])

    client = get_client()
    collection = rebuild_collection(client) if rebuild else get_collection(client)

    upsert_chunks(collection, chunks, embeddings)
    removed = 0
    if not rebuild:
        removed = prune_stale_ids(collection, {c.chunk_id for c in chunks})

    print(f"Pages processed: {pages_processed}")
    print(f"Lines extracted: {len(lines)}")
    print(f"Sections detected: {len(sections)}")
    print(f"Chunks created: {len(chunks)}")
    print(f"Embeddings generated: {len(embeddings)}")
    if removed:
        print(f"Stale chunks removed: {removed}")
    print()
    print("Vector database:")
    print("ChromaDB")
    print()
    print("Collection:")
    print(collection.name)
    print()
    print(f"Total records in collection: {collection.count()}")
    print()
    print("Status:")
    print("SUCCESS")
    print("=" * 40)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--rebuild", action="store_true", help="Drop and recreate the collection")
    args = parser.parse_args()
    run(rebuild=args.rebuild)
