#!/usr/bin/env python3
"""Start the SahulatAI Flask server."""
import os, sys

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(PROJECT_DIR)
sys.path.insert(0, PROJECT_DIR)

from src.vector_store import get_collection
col = get_collection()
if col.count() == 0:
    print("Knowledge base empty — running ingestion...")
    from src.ingest import run
    run(rebuild=True)
    print("Ingestion complete.")

from src.app import app
app.run(debug=False, host="0.0.0.0", port=5050)
