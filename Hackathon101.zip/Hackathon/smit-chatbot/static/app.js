/* ============================================================
   SahulatAI — Client Application
   3-panel layout: sidebar, chat, insights
   ============================================================ */
(function () {
  'use strict';

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => document.querySelectorAll(s);

  // DOM
  const sidebar = $('#sidebar');
  const history = $('#history');
  const searchInput = $('#searchInput');
  const newChatBtn = $('#newChatBtn');
  const welcomeSection = $('#welcomeSection');
  const conversation = $('#conversation');
  const centerContent = $('#centerContent');
  const chatInput = $('#chatInput');
  const sendBtn = $('#sendBtn');
  // actionCards removed per user request
  const menuToggle = $('#menuToggle');
  const mobileOverlay = $('#mobileOverlay');
  const themeLight = $('#themeLight');
  const themeDark = $('#themeDark');

  // State
  const STORAGE_KEY = 'sahulat_conversations';
  const THEME_KEY = 'sahulat_theme';
  let conversations = loadConversations();
  let activeId = null;
  let isStreaming = false;

  // Markdown
  if (typeof marked !== 'undefined') {
    marked.setOptions({ breaks: true, gfm: true });
  }

  // ---- Utilities ----
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function esc(t) { const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
  function md(text) {
    if (typeof marked !== 'undefined') return marked.parse(text);
    return '<p>' + esc(text).replace(/\n/g, '<br>') + '</p>';
  }
  function now() {
    const d = new Date();
    let h = d.getHours(), m = d.getMinutes();
    const ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    return h + ':' + (m < 10 ? '0' : '') + m + ' ' + ampm;
  }

  // ---- Persistence ----
  function loadConversations() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
    catch (_) { return []; }
  }
  function save() { localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations)); }
  function getConv(id) { return conversations.find(c => c.id === id); }

  // ---- Theme ----
  function initTheme() {
    const t = localStorage.getItem(THEME_KEY) || 'light';
    setTheme(t);
  }
  function setTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    localStorage.setItem(THEME_KEY, t);
    if (t === 'dark') {
      themeDark.classList.add('active');
      themeLight.classList.remove('active');
    } else {
      themeLight.classList.add('active');
      themeDark.classList.remove('active');
    }
  }
  themeLight.addEventListener('click', () => setTheme('light'));
  themeDark.addEventListener('click', () => setTheme('dark'));

  // ---- Mobile Sidebar ----
  menuToggle.addEventListener('click', () => {
    sidebar.classList.add('open');
    mobileOverlay.classList.add('show');
  });
  mobileOverlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    mobileOverlay.classList.remove('show');
  });

  // ---- Scrolling Question Cards (bilingual) ----
  const questionsTrack = $('#questionsTrack');
  if (questionsTrack) {
    // Clone cards for seamless infinite scroll
    const cards = questionsTrack.querySelectorAll('.question-card');
    cards.forEach(card => {
      const clone = card.cloneNode(true);
      questionsTrack.appendChild(clone);
    });

    // Handle card click
    questionsTrack.addEventListener('click', (e) => {
      const card = e.target.closest('.question-card');
      if (!card) return;
      const raw = card.dataset.query;
      const parts = raw.split('|');
      const enQ = parts[0].trim();
      const urQ = parts.length > 1 ? parts[1].trim() : enQ;
      // Send both languages as the question
      sendQuestion(enQ + ' | ' + urQ);
    });
  }

  // ---- History Clicks ----
  history.addEventListener('click', (e) => {
    var delBtn = e.target.closest('.h-delete');
    if (delBtn) {
      e.stopPropagation();
      var item = delBtn.closest('.history-item');
      var id = item.dataset.id;
      conversations = conversations.filter(function(c) { return c.id !== id; });
      save();
      item.remove();
      if (activeId === id) {
        activeId = null;
        conversation.innerHTML = '';
        conversation.style.display = 'none';
        welcomeSection.style.display = '';
        chatInput.value = '';
      }
      return;
    }
    var item = e.target.closest('.history-item');
    if (item) {
      $$('.history-item').forEach(function(i) { i.classList.remove('active'); });
      item.classList.add('active');
    }
  });

  // ---- Search ----
  searchInput.addEventListener('input', () => {
    const q = searchInput.value.toLowerCase();
    $$('.history-item').forEach(item => {
      const text = item.querySelector('.h-text').textContent.toLowerCase();
      item.style.display = text.includes(q) ? '' : 'none';
    });
  });

  // ---- New Chat ----
  newChatBtn.addEventListener('click', () => {
    activeId = null;
    conversation.innerHTML = '';
    conversation.style.display = 'none';
    welcomeSection.style.display = '';
    chatInput.value = '';
    chatInput.focus();
    $$('.history-item').forEach(i => i.classList.remove('active'));
  });

  // ---- Send Message ----
  function sendQuestion(text) {
    if (isStreaming || !text.trim()) return;

    // Create conversation if needed
    if (!activeId) {
      const conv = { id: uid(), title: text.slice(0, 60), messages: [], time: Date.now() };
      conversations.unshift(conv);
      activeId = conv.id;
      // Add to sidebar
      const item = document.createElement('div');
      item.className = 'history-item active';
      item.dataset.id = conv.id;
      item.innerHTML = '<span class="h-icon">&#128172;</span><span class="h-text">' + esc(conv.title) + '</span><span class="h-time">' + now() + '</span><button class="h-delete" title="Delete chat" aria-label="Delete chat">&times;</button>';
      const firstLabel = history.querySelector('.history-label');
      if (firstLabel && firstLabel.nextElementSibling) {
        history.insertBefore(item, firstLabel.nextElementSibling);
      } else {
        history.prepend(item);
      }
      $$('.history-item').forEach(i => { if (i !== item) i.classList.remove('active'); });
    }

    // Show conversation
    welcomeSection.style.display = 'none';
    conversation.style.display = '';

    // Add user message
    const userHtml =
      '<div class="msg user">' +
        '<div class="msg-body"><div class="msg-bubble">' + esc(text.trim()) + '</div></div>' +
        '<div class="msg-meta"><div class="msg-avatar user-av">U</div><span class="msg-time">' + now() + '</span></div>' +
      '</div>';
    conversation.insertAdjacentHTML('beforeend', userHtml);
    scrollDown();

    // Clear input
    chatInput.value = '';
    chatInput.style.height = 'auto';

    // Show thinking
    isStreaming = true;
    sendBtn.disabled = true;

    const thinkHtml =
      '<div class="msg bot thinking-msg">' +
        '<div class="msg-avatar bot-av"><img src="/static/logo.png" alt=""></div>' +
        '<div class="msg-body">' +
          '<div class="msg-name">SahulatAI</div>' +
          '<div class="msg-bubble" id="streamBubble"><span style="color:var(--text-muted);">Thinking<span class="typing-dots"><span>.</span><span>.</span><span>.</span></span></span></div>' +
        '</div>' +
      '</div>';
    conversation.insertAdjacentHTML('beforeend', thinkHtml);
    scrollDown();

    // Add typing dots CSS if not present
    if (!$('#typing-css')) {
      const style = document.createElement('style');
      style.id = 'typing-css';
      style.textContent = '.typing-dots span{animation:dotBounce 1.2s ease-in-out infinite;}.typing-dots span:nth-child(2){animation-delay:.15s;}.typing-dots span:nth-child(3){animation-delay:.3s;}@keyframes dotBounce{0%,60%,100%{opacity:.3;}30%{opacity:1;}}';
      document.head.appendChild(style);
    }

    // SSE stream
    fetch('/api/chat/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text.trim() })
    }).then(resp => {
      if (!resp.ok) throw new Error('Server error');
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let full = '';

      function process() {
        reader.read().then(({ value, done }) => {
          if (done) {
            finishStream(full, []);
            return;
          }
          buffer += decoder.decode(value, { stream: true });
          const parts = buffer.split('\n\n');
          buffer = parts.pop() || '';
          for (const part of parts) {
            if (!part.startsWith('data: ')) continue;
            try {
              const p = JSON.parse(part.slice(6));
              if (p.token) { full += p.token; updateStream(full); }
              if (p.error) { full = p.error; updateStream(full); }
              if (p.done) finishStream(full, p.sources || []);
            } catch (_) {}
          }
          process();
        });
      }
      process();
    }).catch(err => {
      finishStream('Something went wrong. Please try again.', []);
    });
  }

  function updateStream(text) {
    const b = $('#streamBubble');
    if (!b) return;
    b.innerHTML = md(text);
    scrollDown();
  }

  function finishStream(text, sources) {
    const b = $('#streamBubble');
    if (!b) return;
    b.removeAttribute('id');
    b.innerHTML = md(text);

    // Sources
    if (sources.length > 0) {
      let sh = '<div style="margin-top:10px;padding:8px 12px;background:var(--gradient-soft);border:1px solid var(--border);border-radius:8px;font-size:0.78rem;color:var(--text-sec);">';
      sh += '<div style="font-weight:600;margin-bottom:4px;color:var(--text);font-size:0.72rem;text-transform:uppercase;letter-spacing:.04em;">Sources</div>';
      for (const s of sources) {
        const pg = s.page_start === s.page_end ? s.page_start : s.page_start + '-' + s.page_end;
        sh += '<div style="padding:3px 0;">&#128196; ' + esc(s.document || 'SMIT_Master_Knowledge_Base.pdf') + ' &mdash; Page ' + pg + ' &bull; Lines ' + s.line_start + '-' + s.line_end;
        if (s.section) sh += ' &bull; ' + esc(s.section);
        sh += '</div>';
      }
      sh += '</div>';
      b.insertAdjacentHTML('beforeend', sh);
    }

    // Actions
    const actions =
      '<div class="msg-actions">' +
        '<button class="msg-action-btn" data-action="helpful">&#128077; Helpful | مفید</button>' +
        '<button class="msg-action-btn" data-action="not-helpful">&#128078; Not helpful | غیر مفید</button>' +
        '<button class="msg-action-btn" data-action="copy">&#128203; Copy | کاپی</button>' +
        '<button class="msg-action-btn" data-action="regenerate">&#128260; Regenerate | دوبارہ بنائیں</button>' +
      '</div>';
    b.insertAdjacentHTML('afterend', actions);

    // Remove thinking class
    const msg = b.closest('.thinking-msg');
    if (msg) msg.classList.remove('thinking-msg');

    // Save to state
    const conv = getConv(activeId);
    if (conv) {
      conv.messages.push({ role: 'assistant', content: text });
      save();
    }

    isStreaming = false;
    sendBtn.disabled = false;
    scrollDown();
  }

  function scrollDown() {
    centerContent.scrollTop = centerContent.scrollHeight;
  }

  // ---- Input Events ----
  sendBtn.addEventListener('click', () => sendQuestion(chatInput.value));

  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendQuestion(chatInput.value);
    }
  });

  chatInput.addEventListener('input', () => {
    chatInput.style.height = 'auto';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 100) + 'px';
  });

  // ---- Message Actions (delegated) ----
  function showFeedbackPopup(type) {
    const old = document.querySelector('.feedback-popup');
    if (old) old.remove();
    const popup = document.createElement('div');
    popup.className = 'feedback-popup ' + type;
    if (type === 'thanks') {
      popup.innerHTML = '<span class="fp-text">Thanks for your feedback! <span class="urdu-sub" style="font-size:0.78rem;color:var(--text-muted);display:block;margin-top:2px;">آپ کی رائے کا شکریہ!</span></span><button class="fp-close">&times;</button>';
    } else {
      popup.innerHTML = '<span class="fp-text">Sorry about that. Should I try a different answer? <span class="urdu-sub" style="font-size:0.78rem;color:var(--text-muted);display:block;margin-top:2px;">ماف کیجیے، کیا میں ایک اور جواب دوں؟</span></span><button class="fp-close">&times;</button>';
    }
    popup.querySelector('.fp-close').addEventListener('click', () => popup.remove());
    document.body.appendChild(popup);
    setTimeout(() => { if (popup.parentNode) popup.remove(); }, 4000);
  }

  conversation.addEventListener('click', (e) => {
    const btn = e.target.closest('.msg-action-btn');
    if (!btn) return;
    const action = btn.dataset.action;
    const bubble = btn.closest('.msg-body').querySelector('.msg-bubble');

    if (action === 'helpful') {
      showFeedbackPopup('thanks');
    } else if (action === 'not-helpful') {
      showFeedbackPopup('retry');
    } else if (action === 'copy' && bubble) {
      navigator.clipboard.writeText(bubble.innerText).then(() => {
        const orig = btn.innerHTML;
        btn.innerHTML = '&#10003; Copied';
        setTimeout(() => { btn.innerHTML = orig; }, 1500);
      });
    } else if (action === 'regenerate') {
      const msgs = conversation.querySelectorAll('.msg.bot');
      if (msgs.length > 0) msgs[msgs.length - 1].remove();
      const userMsgs = conversation.querySelectorAll('.msg.user');
      if (userMsgs.length > 0) {
        const last = userMsgs[userMsgs.length - 1];
        const text = last.querySelector('.msg-bubble').textContent;
        sendQuestion(text);
      }
    }
  });

  // ---- Clear Chat ----
  const clearChatBtn = $('#clearChatBtn');
  clearChatBtn.addEventListener('click', () => {
    conversation.innerHTML = '';
    conversation.style.display = 'none';
    welcomeSection.style.display = '';
    chatInput.value = '';
    activeId = null;
    history.querySelectorAll('.history-item').forEach(i => i.classList.remove('active'));
    chatInput.focus();
  });

  // ---- Init ----
  localStorage.removeItem(STORAGE_KEY);
  conversations = [];
  initTheme();
  chatInput.focus();

  // ---- Important Notice Modal ----
  const noticeOverlay = $('#noticeOverlay');
  const noticeCloseBtn = $('#noticeCloseBtn');
  const whatsappForm = $('#whatsappForm');
  const noticeSuccess = $('#noticeSuccess');

  // Show modal on page load
  noticeOverlay.style.display = 'flex';

  // Close modal
  noticeCloseBtn.addEventListener('click', () => {
    noticeOverlay.style.display = 'none';
  });

  // Close on overlay click
  noticeOverlay.addEventListener('click', (e) => {
    if (e.target === noticeOverlay) {
      noticeOverlay.style.display = 'none';
    }
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && noticeOverlay.style.display === 'flex') {
      noticeOverlay.style.display = 'none';
    }
  });

  // Submit WhatsApp credentials
  whatsappForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const payload = {
      access_token: $('#waToken').value.trim(),
      phone_number_id: $('#waPhoneId').value.trim(),
      business_account_id: $('#waBusinessId').value.trim(),
      verify_token: $('#waVerifyToken').value.trim()
    };

    fetch('/api/whatsapp/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(resp => resp.json()).then(data => {
      if (data.success) {
        whatsappForm.style.display = 'none';
        noticeSuccess.style.display = 'block';
      } else {
        alert(data.error || 'Failed to save credentials.');
      }
    }).catch(() => {
      alert('Network error. Please try again.');
    });
  });
})();
